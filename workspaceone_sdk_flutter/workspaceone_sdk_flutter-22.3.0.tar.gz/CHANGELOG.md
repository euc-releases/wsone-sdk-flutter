## 1.2.0

* Initial release:VMware Workspace ONE SDK for Flutter allows you to integrate the Workspace ONE SDKs for iOS and Android into your Flutter.

## 22.1.0

* VMware Workspace ONE SDK for Flutter is updated to SDK version 21.11.0

## 22.3.0

* VMware Workspace ONE SDK for Flutter is updated to SDK version 22.2.0