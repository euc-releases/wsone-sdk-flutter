import Flutter
import UIKit
import AWSDK
import WorkspaceOneSDKBridge
public class SwiftWorkspaceoneSdkFlutterPlugin: NSObject, FlutterPlugin,FlutterStreamHandler,WSOSDKBridgeDelegate {
   
    var eventSink: FlutterEventSink?
    static let PLUGIN_METHOD_CHANNEL = "workspaceone_sdk_flutter"
    static let PLUGIN_EVENT_CHANNEL = "workspaceone_sdk_event"
    static let CALLBACK_SCHEME = "awsdkcallback"
    static let ERROR_DOMAIN = "com.error.ws1sdk"
    static let EVENT_INIT_SUCCESS = "initSuccess"
    static let EVENT_INIT_FAILURE = "initFailure"
    static let EVENT_WIPE = "wipe"
    static let EVENT_LOCK = "lock"
    static let EVENT_UNLOCK = "unlock"
    static let EVENT_STOP_NETWORK_ACTIVITY = "stopNetworkActivity"
    static let EVENT_RESUME_NETWORK_ACTIVITY = "resumeNetworkActivity"
    static let ERROR_NO_GROUP = ("no_groupId", "missing groupId")
    static let ERROR_NO_USERNAME = ("no_userName", "missing userName")
    static let ERROR_NO_SERVERNAME = ("no_serverName", "missing serverName")
    static let ERROR_NO_CUSTM_SETTINGS = ("no_customSettings", "missing customSettings")
    var wsosdkBridge : WSOSBridge =  WSOSBridge.sharedInstance()
    
    /*
     * Initialize the SDKBridge and Start SDK.
     */
    func pluginInitialize(){
        self.wsosdkBridge.bridgeDelegate = self
        self.wsosdkBridge.startWorkspaceOneSDK()
    }
    
    /*
     * Start SDK.
     */
    func startSDK(){
        self.pluginInitialize()
    }
    
    /*
     * Plugin Registeration
     */
    public static func register(with registrar: FlutterPluginRegistrar) {
        let instance = SwiftWorkspaceoneSdkFlutterPlugin()
        let methodChannel = FlutterMethodChannel(name: SwiftWorkspaceoneSdkFlutterPlugin.PLUGIN_METHOD_CHANNEL, binaryMessenger: registrar.messenger())
        registrar.addMethodCallDelegate(instance, channel: methodChannel)
        let eventChannel = FlutterEventChannel(name: SwiftWorkspaceoneSdkFlutterPlugin.PLUGIN_EVENT_CHANNEL,binaryMessenger: registrar.messenger())
        eventChannel.setStreamHandler(instance)
    }
    
    public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        
        switch call.method {
            case "startSDK":
                startSDK()
            case "userName":
                result(wsosdkBridge.username())
            case "groupId":
                result(wsosdkBridge.groupId())
            case "serverName":
                result(wsosdkBridge.serverName())
            case "allowCopyPaste":
                result(wsosdkBridge.allowCopyPaste())
            case "allowOffline":
                result(wsosdkBridge.allowOffline())
            case "restrictDocumentToApps":
                result(wsosdkBridge.restrictDocumentToApps())
            case "allowedApplications":
                result(wsosdkBridge.allowedApplications())
            case "customSettings":
                result(wsosdkBridge.customSettings())
            case "isCompliant":
            wsosdkBridge.isCompliant(completion:{ flag in
                result(flag)
            })
            case "isEnrolled":
            wsosdkBridge.isEnrolled({ flag,error  in
                if(error != nil){
                    result(false)
                }
                else{
                    result(flag)
                }
            })
            case "isCompromised":
            wsosdkBridge.isCompromised(completion:{ flag in
                result(flag)
            })
            case "openFile":
                guard let args = call.arguments else {
                    return
                }
                if let myArgs = args as? [String: Any],
                   let path = myArgs["path]"] as? String {
                    result(wsosdkBridge.open(filePath: path))
                } else {
                    result(FlutterError(code: "-1", message: "iOS could not extract " +
                                            "flutter arguments in method: (openFile)", details: nil))
                }
                break;
            case "registerPushNotificationToken":
                guard let args = call.arguments else {
                    return
                }
                if let myArgs = args as? [String: Any],
                   let token = myArgs["token]"] as? String {
                    result(wsosdkBridge.registerPushNotificationToken(token: token))
                } else {
                    result(FlutterError(code: "-1", message: "iOS could not extract " +
                                            "flutter arguments in method: (registerPushNotificationToken)", details: nil))
                }
                break;
            default:
                result(FlutterMethodNotImplemented)
        }
    }
    
    public func onListen(withArguments arguments: Any?, eventSink events: @escaping FlutterEventSink) -> FlutterError? {
        
        eventSink = events
        return nil
    }
    
    public func onCancel(withArguments arguments: Any?) -> FlutterError? {
        eventSink = nil
        return nil
    }
    
    
    func sendEvent(_ event:String)-> Void {
        guard let eventSink = eventSink else {
            return
        }
        eventSink(event)
    }
    
    public func initSuccess() {
        sendEvent(SwiftWorkspaceoneSdkFlutterPlugin.EVENT_INIT_SUCCESS)
    }
    
    public func initFailure() {
        sendEvent(SwiftWorkspaceoneSdkFlutterPlugin.EVENT_INIT_FAILURE)
    }
    
    public func wipe() {
        sendEvent(SwiftWorkspaceoneSdkFlutterPlugin.EVENT_WIPE)
    }
    
    public func lock() {
        sendEvent(SwiftWorkspaceoneSdkFlutterPlugin.EVENT_LOCK)
    }
    
    public func unlock() {
        sendEvent(SwiftWorkspaceoneSdkFlutterPlugin.EVENT_UNLOCK)
    }
    
    public func stopNetworkActivity(_ networkActivityStatus: Int) {
        sendEvent(SwiftWorkspaceoneSdkFlutterPlugin.EVENT_STOP_NETWORK_ACTIVITY)
    }
    
    public func resumeNetworkActivity() {
        sendEvent(SwiftWorkspaceoneSdkFlutterPlugin.EVENT_RESUME_NETWORK_ACTIVITY)
    }
}
