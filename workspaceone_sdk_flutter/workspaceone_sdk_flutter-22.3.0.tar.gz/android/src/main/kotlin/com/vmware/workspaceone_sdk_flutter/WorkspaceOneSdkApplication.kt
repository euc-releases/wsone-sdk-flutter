package com.vmware.workspaceone_sdk_flutter

import android.app.Application
import android.content.Intent
import com.airwatch.app.AWApplication
import com.airwatch.util.Logger.v
import java.security.cert.X509Certificate

open class WorkspaceOneSdkApplication: AWApplication() {

    private val TAG = WorkspaceOneSdkApplication::class.java.simpleName

    override fun onCreate(app: Application){
        super.onCreate(app)
    }
    override fun getMainActivityIntent(): Intent {

        return Intent(this,WorkspaceOneSdkActivity::class.java)
    }

    override fun onSSLPinningRequestFailure(host: String, serverCACert: X509Certificate?) {
        v(TAG, "SSLPinning request failed for host: $host")
    }

    override fun onSSLPinningValidationFailure(host: String, serverCACert: X509Certificate?) {
        v(TAG, "SSLPinning validation failed for host: $host")
    }
}