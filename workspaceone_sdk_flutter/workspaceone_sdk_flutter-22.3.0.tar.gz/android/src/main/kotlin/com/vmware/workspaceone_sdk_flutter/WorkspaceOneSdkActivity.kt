package com.vmware.workspaceone_sdk_flutter

import com.airwatch.login.IProxyStatusCallback
import com.airwatch.login.SDKBaseActivityDelegate
import io.flutter.embedding.android.FlutterActivity

open class WorkspaceOneSdkActivity : FlutterActivity(), SDKBaseActivityDelegate.Callback, IProxyStatusCallback {
    override fun proxyStatusUpdated(i: Int) {}
    override fun onTimeOut(sdkBaseActivityDelegate: SDKBaseActivityDelegate) {}
    override fun onPointerCaptureChanged(hasCapture: Boolean) {}
}