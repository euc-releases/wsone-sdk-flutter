//
//  WorkspaceOneSDKBridge.h
//  WorkspaceOneSDKBridge
//
//  Created by Amit Kalghatgi on 11/03/21.
//

#import <Foundation/Foundation.h>
#import "AWProfileWrapper.h"
//! Project version number for WorkspaceOneSDKBridge.
FOUNDATION_EXPORT double WorkspaceOneSDKBridgeVersionNumber;

//! Project version string for WorkspaceOneSDKBridge.
FOUNDATION_EXPORT const unsigned char WorkspaceOneSDKBridgeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WorkspaceOneSDKBridge/PublicHeader.h>

