//
//  AWProfileWrapper.h
//  WorkspaceOneSDKBridge
//
//  Created by Amit Kalghatgi on 15/09/21.
//

#import <Foundation/Foundation.h>
#import <AWSDK/AWSDK.h>
NS_ASSUME_NONNULL_BEGIN
@interface AWProfileWrapper : NSObject

/**
 * @brief The designated intializer to create a profile wrapper.
 * @param profile A representation of a profile payload.
 * @return A newly initialized profile wrapper.
 */
- (NSDictionary *)dictionary:(AWProfile * )profile ;
@end

NS_ASSUME_NONNULL_END
