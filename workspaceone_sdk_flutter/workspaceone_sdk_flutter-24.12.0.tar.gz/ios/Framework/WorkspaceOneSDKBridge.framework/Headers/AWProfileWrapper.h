//
//  AWProfileWrapper.h
//  WorkspaceOneSDKBridge
//
//  Copyright (c) Omnissa, LLC. All rights reserved.
//  This product is protected by copyright and intellectual property laws in the
//  United States and other countries as well as by international treaties.
//  -- Omnissa Restricted
//

#import <Foundation/Foundation.h>
#import <AWSDK/AWSDK.h>
NS_ASSUME_NONNULL_BEGIN
@interface AWProfileWrapper : NSObject

/**
 * @brief The designated intializer to create a profile wrapper.
 * @param profile A representation of a profile payload.
 * @return A newly initialized profile wrapper.
 */
- (NSDictionary *)dictionary:(AWProfile * )profile ;
@end

NS_ASSUME_NONNULL_END
