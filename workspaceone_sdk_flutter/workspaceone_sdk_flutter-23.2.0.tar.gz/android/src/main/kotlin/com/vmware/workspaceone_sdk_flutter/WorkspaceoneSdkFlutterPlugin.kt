package com.vmware.workspaceone_sdk_flutter

import android.app.Activity
import android.content.Context
import android.net.Uri
import androidx.annotation.NonNull
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry.Registrar
import com.vmware.ws1androidsdkbridge.WorkspaceOneSdkBridge
import com.vmware.ws1androidsdkbridge.InitializationListener
/** WorkspaceoneSdkFlutterPlugin */
class WorkspaceoneSdkFlutterPlugin: FlutterPlugin, MethodCallHandler, ActivityAware, EventChannel.StreamHandler {
  /// The MethodChannel that will the communication between Flutter and native Android
  ///
  /// This local reference serves to register the plugin with the Flutter Engine and unregister it
  /// when the Flutter Engine is detached from the Activity
  private lateinit var channel : MethodChannel
  private lateinit var bridge : WorkspaceOneSdkBridge
  private lateinit var context : Context
  private lateinit var activity:Activity
  var eventSink: EventChannel.EventSink? = null
  /**
   * Event flow channel
   * Native Frequently send messages to Flutter, such as monitoring network status, Bluetooth devices, etc., and then send them to Flutter
   */
  private  var eventChannel: EventChannel? = null
  override fun onAttachedToEngine(@NonNull flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
    context = flutterPluginBinding.applicationContext
    channel = MethodChannel(flutterPluginBinding.binaryMessenger, "workspaceone_sdk_flutter")
    channel.setMethodCallHandler(this)
    eventChannel = EventChannel(flutterPluginBinding.binaryMessenger, "workspaceone_sdk_event")
    eventChannel?.setStreamHandler(this)
  }
  override fun onMethodCall(@NonNull call: MethodCall, @NonNull result: Result) {

    when(call.method){
      "startSDK" -> {
        startSDK()
      }
      "userName" -> {
        result.success(bridge.userName)
      }
      "groupId" -> {
        result.success(bridge.groupId)
      }
      "serverName" -> {
        result.success(bridge.serverName)
      }
      "allowCopyPaste" -> {
        result.success(bridge.allowCopyPaste)
      }
      "allowOffline" -> {
        result.success(bridge.isOfflineAllowed)
      }
      "restrictDocumentToApps" -> {
        result.success(bridge.restrictDocumentToApps)
      }
      "allowedApplications" -> {
        result.success(bridge.allowedApplications())
      }
      "isCompliant" -> {
        result.success(bridge.isCompliant)
      }
      "isCompromised" -> {
        result.success(bridge.isCompromised)
      }
      "isEnrolled" -> {
        result.success(bridge.isEnrolled)
      }
      "customSettings" -> {
        result.success(bridge.customSettings)
      }
      "openFile" -> {
        val uri :String? = call.argument("path")
        bridge.openFile(Uri.parse(uri))
      }
      "registerPushNotificationToken" -> {
        val token :String? = call.argument("token")
        if (token != null) {
          bridge.registerPushNotificationToken(token)
        }
      }
      else -> {
        result.notImplemented()
      }
    }
  }

  override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
    channel.setMethodCallHandler(null)
    eventChannel?.setStreamHandler(null)
    eventChannel = null
  }

  private val initListener: InitializationListener = object : InitializationListener {
    override fun initSuccess() {
      activity.runOnUiThread {
        eventSink?.success("initSuccess")
      }
    }

    override fun initFailure() {
      activity.runOnUiThread {
        eventSink?.success("initFailure")
      }
    }
  }
  private fun startSDK() {
    bridge = WorkspaceOneSdkBridge.instance
    bridge.initWorkspaceOneSDKManager(activity, initListener )
  }

  // This static function is optional and equivalent to onAttachedToEngine. It supports the old
  // pre-Flutter-1.12 Android projects. You are encouraged to continue supporting
  // plugin registration via this function while apps migrate to use the new Android APIs
  // post-flutter-1.12 via https://flutter.dev/go/android-project-migration.
  //
  // It is encouraged to share logic between onAttachedToEngine and registerWith to keep
  // them functionally equivalent. Only one of onAttachedToEngine or registerWith will be called
  // depending on the user's project. onAttachedToEngine or registerWith must both be defined
  // in the same class.
  companion object {
    @JvmStatic
    fun registerWith(registrar: Registrar) {
      val channel = MethodChannel(registrar.messenger(), "workspaceone_sdk_flutter")
      channel.setMethodCallHandler(WorkspaceoneSdkFlutterPlugin())
    }
  }
  override fun onAttachedToActivity(binding: ActivityPluginBinding) {
    activity = binding.activity;
  }

  override fun onDetachedFromActivityForConfigChanges() {
  }

  override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
    onAttachedToActivity(binding)
  }

  override fun onDetachedFromActivity() {
  }

  override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
    if (events != null) {
      eventSink = events
    }
  }

  override fun onCancel(arguments: Any?) {
    eventSink = null
  }


}

