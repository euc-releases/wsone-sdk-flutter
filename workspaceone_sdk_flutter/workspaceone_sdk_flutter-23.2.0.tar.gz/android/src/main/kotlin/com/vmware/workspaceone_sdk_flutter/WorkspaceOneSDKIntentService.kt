package com.vmware.workspaceone_sdk_flutter

import android.content.Context
import android.os.Bundle
import android.util.Log
import com.airwatch.sdk.AirWatchSDKBaseIntentService
import com.airwatch.sdk.profile.AnchorAppStatus
import com.airwatch.sdk.profile.ApplicationProfile
import com.airwatch.sdk.shareddevice.ClearReasonCode

class WorkspaceOneSDKIntentService : AirWatchSDKBaseIntentService() {
    override fun onApplicationConfigurationChange(bundle: Bundle) {}
    override fun onApplicationProfileReceived(context: Context, s: String, applicationProfile: ApplicationProfile) {
        Log.d("SDK Init", "onApplicationProfileReceived")
    }

    override fun onClearAppDataCommandReceived(context: Context, clearReasonCode: ClearReasonCode) {
        Log.d("SDK Init", "onClearAppDataCommandReceived")
    }

    override fun onAnchorAppStatusReceived(context: Context, anchorAppStatus: AnchorAppStatus) {}
    override fun onAnchorAppUpgrade(context: Context, b: Boolean) {}
}