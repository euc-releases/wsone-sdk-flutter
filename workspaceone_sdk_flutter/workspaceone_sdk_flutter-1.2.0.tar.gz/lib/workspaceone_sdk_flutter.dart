
import 'dart:async';

import 'package:flutter/services.dart';

class WorkspaceoneSdkFlutter {
  static const MethodChannel _channel =
      const MethodChannel('workspaceone_sdk_flutter');

  static Future<String> get platformVersion async {
    final String version = await _channel.invokeMethod('getPlatformVersion');
    return version;
  }

  static Future<void> get startSDK async {
     await _channel.invokeMethod('startSDK');
     return;
  }

  static Future<String> get userName async {
    final String userName = await _channel.invokeMethod('userName');
    return userName;
  }

  static Future<String> get groupId async {
    final String groupId = await _channel.invokeMethod('groupId');
    return groupId;
  }

  static Future<String> get serverName async {
    final String serverName = await _channel.invokeMethod('serverName');
    return serverName;
  }


  static Future<bool> get allowCopyPaste async {
    final bool allowCopyPaste = await _channel.invokeMethod('allowCopyPaste');
    return allowCopyPaste;
  }

  static Future<bool> get allowOffline async {
    final bool allowOffline = await _channel.invokeMethod('allowOffline');
    return allowOffline;
  }

  static Future<String> get customSettings async {
    final String customSettings = await _channel.invokeMethod('customSettings');
    return customSettings;
  }

  static Future<bool> get isCompliant async {
    final bool isCompliant = await _channel.invokeMethod('isCompliant');
    return isCompliant;
  }

  static Future<bool> get isCompromised async {
    final bool isCompromised = await _channel.invokeMethod('isCompromised');
    return isCompromised;
  }

 static Future<bool> get isEnrolled async {
    final bool isEnrolled = await _channel.invokeMethod('isEnrolled');
    return isEnrolled;
  }


  static Future<bool> get restrictDocumentToApps async {
    final bool restrictDocumentToApps = await _channel.invokeMethod('restrictDocumentToApps');
    return restrictDocumentToApps;
  }

  static Future<List<String>> get allowedApplications async {
    final List<String> allowedApplications = await _channel.invokeMethod('allowedApplications');
    return allowedApplications;
  }

  static Future<bool>  openFile(String path) async {
    final bool version = await _channel.invokeMethod('openFile',<String, dynamic>{
        'path': path
      });
    return version;
  }

  static Future<void>  registerPushNotificationToken(String token) async {
    return await _channel.invokeMethod('registerPushNotificationToken',<String, dynamic>{
        'token': token
      });
  }

}
