//
//  String+Helper.swift
//  WorkspaceOneSdk
//
//  Created by VMWare, Inc.
//  Copyright © 2020 VMware, Inc. All rights reserved.
//  This product is protected by copyright and intellectual property laws in the United States and other countries as well as by international treaties.
//  WorkspaceOne products may be covered by one or more patents listed at http:www.vmware.com/go/patents.
//

extension String {
    func trimmingTrailingCharacters(in set: CharacterSet?) -> String? {
        var rangeOfLaststWantedCharacter: NSRange? = nil
        if let inverted = set?.inverted {
            rangeOfLaststWantedCharacter = (self as NSString).rangeOfCharacter(from: inverted, options: .backwards)
        }
        if rangeOfLaststWantedCharacter?.location == NSNotFound {
            return ""
        }
        return (self as NSString).substring(to: (rangeOfLaststWantedCharacter?.location ?? 0) + 1)
    }
}
