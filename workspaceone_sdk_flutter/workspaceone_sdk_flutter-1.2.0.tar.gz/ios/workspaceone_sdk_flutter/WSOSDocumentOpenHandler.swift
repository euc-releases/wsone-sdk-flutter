//
//  WSOSDocumentOpenHandler.swift
//  WorkspaceOneSdk
//
//  Created by VMWare, Inc.
//  Copyright © 2020 VMware, Inc. All rights reserved.
//  This product is protected by copyright and intellectual property laws in the United States and other countries as well as by international treaties.
//  WorkspaceOne products may be covered by one or more patents listed at http:www.vmware.com/go/patents.
//

import Foundation


class WSOSDocumentOpenHandler : NSObject, UIDocumentInteractionControllerDelegate {
    weak var sourceViewController: UIViewController?
    var fileURL: URL?
    var showRestrictedAlert = false
    var restrictDocumentToApps = false
    var whitelistedApplications: [String] = []
    
    override init(){
        super.init()
    }
    
    init(sourceViewController viewController: UIViewController?) {
        super.init()
        if let viewController = viewController {
            sourceViewController = viewController
        }
    }
    
    func open(_ fileURL: URL) {
        self.fileURL = fileURL
        
        
        let documentInteractionController = UIDocumentInteractionController(url: tempFileURLfrom(fileURL))
        documentInteractionController.delegate = self
        
        // We need to provide a frame from where the menu should appear, keep it as CGRectZero for now since there is no way to find the exact touch point from the cordova web view
        DispatchQueue.main.async(execute: { [self] in
            documentInteractionController.presentOpenInMenu(from: CGRect.zero, in: (sourceViewController?.view)!, animated: true)
        })
        
    }
    
    func canOpen(inApplication appBundleID: String?) -> Bool {
        var allowApp = true
        if restrictDocumentToApps {
            allowApp = false
        }
        
        if (whitelistedApplications.count > 0) {
            for appID in whitelistedApplications {
                if appBundleID?.caseInsensitiveCompare(appID) == .orderedSame {
                    allowApp = true
                    break
                }
            }
        }
        return allowApp
    }
    
    func tempFileURLfrom(_ originalURL: URL) -> URL {
        let filename = originalURL.lastPathComponent
        let directoryPath = URL(fileURLWithPath: originalURL.path).deletingLastPathComponent().path
        let tempPath = directoryPath + "/vmware/" + filename
        return URL(fileURLWithPath: tempPath)
    }
    
    func documentInteractionController(_ controller: UIDocumentInteractionController, willBeginSendingToApplication application: String?) {
        let canOpen = self.canOpen(inApplication: application)
        if restrictDocumentToApps && !canOpen {
            print("Oopz! Your company policy blocks opening the document to this application")
            showRestrictedAlert = true
        } else {
            print("Opening document to \(application ?? "")")
            controller.url = fileURL
            showRestrictedAlert = false
        }
    }
    
    func documentInteractionControllerDidDismissOpenInMenu(_ controller: UIDocumentInteractionController) {
        if showRestrictedAlert {
            print("Showing document restricted alert")
            let alert = UIAlertController(title: "Blocked", message: "Your company policy blocks opening the document to this application.", preferredStyle: .alert)
            let CancelButtonAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(CancelButtonAction)
            sourceViewController?.present(alert, animated: true)
            showRestrictedAlert = false
        }
        print("Document interaction controller dismissed")
    }
}
