//
//  WSOSCertificateUtility.swift
//  WorkspaceOneSdk
//
//  Created by VMWare, Inc.
//  Copyright © 2020 VMware, Inc. All rights reserved.
//  This product is protected by copyright and intellectual property laws in the United States and other countries as well as by international treaties.
//  WorkspaceOne products may be covered by one or more patents listed at http:www.vmware.com/go/patents.
//

import Foundation

struct ErrorDetails{
    //define error code and error domain for error message localization
    static let Certificate_Provider_Error_Domain = "ERR_Certificate_Provider"
    static let ERR_ShowUI_Delegate_Html = -1
    static let ERR_ShowUI_Delegate_ViewController = -2
    static let ERR_ShowUI_Delegate_No_UI_Settings = -3
    static let ERR_Set_Parameters_Failed = -4
    static let ERR_Certificate_File_Not_Exist = -5
    static let ERR_Load_Certificate_From_File_Failed = -6
    static let ERR_Save_Certificate_To_KeyChain_Failed = -7
    static let ERR_Read_KeyChain_Item_Failed = -8
    static let ERR_Delete_Saved_Certificate_Failed = -9
    static let ERR_Output_Parameter_Was_Null = -10
}


struct SecurityAttribute {
    static let SEC_ATTR_LABEL = kSecAttrLabel as String
    static let SEC_ATTR_APPL_TAG = kSecAttrApplicationTag as String
    static let SEC_CLASS = kSecClass as String
    static let SEC_CLASS_IDENTITY = kSecClassIdentity as String
    static let SEC_CLASS_CERTIFICATE = kSecClassCertificate as String
    static let SEC_RETURN_REF = kSecReturnRef as String
    static let SEC_RETURN_ATTRIBUTES = kSecReturnAttributes as String
    static let SEC_VALUE_REF = kSecValueRef as String
    static let SEC_MATCH_LIMIT = kSecMatchLimit as String
    static let SEC_MATCH_LIMIT_ALL = kSecMatchLimitAll as String
    static let SEC_ATTR_KEY_CLASS = kSecAttrKeyClass as String
    static let SEC_ATTR_KEY_CLASS_PRIVATE = kSecAttrKeyClassPrivate as String
    static let SEC_IMPORT_EXPORT_PASSWD = kSecImportExportPassphrase as String
}


class WSOSCertificateUtility {
    static let LOG_TAG = "CERTIFICATE_PROVIDER"
    
    static let AW_CERT_PROVIDER_LABEL = "AWx509CertificateProviderIdentity"
    class func importCertToKeychain(certData data: Data, password pswd: String, identityRef:inout SecIdentity?, errorRef : inout Error?) {
        
        guard identityRef != nil else {
            errorRef = NSError.init(domain: ErrorDetails.Certificate_Provider_Error_Domain,
                                    code: ErrorDetails.ERR_Output_Parameter_Was_Null,
                                    userInfo: [NSLocalizedDescriptionKey : "identityRef cannot be null!"])
            return
        }
        
        identityRef = nil
        errorRef = nil
        var tempIdRef : SecIdentity? = nil
        self.deleteStoredCertificate(errorRef: &errorRef)
        
        tempIdRef = self.createCertificate(fromData:data,
                                           password:pswd,
                                           error:&errorRef)
        
        guard errorRef != nil else {
            return
        }
        
        self.addCertificateToKeychain(tempRef: tempIdRef, permRef: &identityRef, errorRef: &errorRef)
    }
    
    class func createCertificate(fromData data : Data, password pswd : String, error eRef: inout Error?  )-> SecIdentity?{
        var identityRef : SecIdentity? = nil
        eRef = nil
        var items : CFArray? = nil
        var status: OSStatus = noErr
        let p12data = data as CFData?

        let options = [
            SecurityAttribute.SEC_IMPORT_EXPORT_PASSWD: pswd,
            SecurityAttribute.SEC_RETURN_REF: NSNumber(value: true),
            SecurityAttribute.SEC_RETURN_ATTRIBUTES: NSNumber(value: true)
        ] as [String : Any]

        if let p12data = p12data, let options = options as CFDictionary? {
            status = SecPKCS12Import(p12data, options, &items)
        }

        if status != errSecSuccess {
            eRef = NSError(domain: ErrorDetails.Certificate_Provider_Error_Domain, code: ErrorDetails.ERR_Load_Certificate_From_File_Failed, userInfo: [
                NSLocalizedDescriptionKey: "Certificate data invalid."
            ])
            return nil
        }

        let identityAndTrust = CFArrayGetValueAtIndex(items, CFIndex(0)) as! CFDictionary?
        identityRef = unsafeBitCast(CFDictionaryGetValue(identityAndTrust, unsafeBitCast(kSecImportItemIdentity, to: UnsafeRawPointer.self)), to: SecIdentity.self)

        return identityRef
        
    }
    class func getStoredCertificate(identityRef iRef :inout SecIdentity?, error eRef: inout Error?) -> Bool {
        
        guard iRef != nil else {
            eRef = NSError.init(domain: ErrorDetails.Certificate_Provider_Error_Domain,
                                code: ErrorDetails.ERR_Output_Parameter_Was_Null,
                                    userInfo: [NSLocalizedDescriptionKey : "identityRef cannot be null!"])
            return false
        }
        
        iRef = findCertificateInKeychainWith(label: AW_CERT_PROVIDER_LABEL, error: &eRef)
        return (eRef == nil)
    }
    
    class func findCertificateInKeychainWith(label : String, error : inout Error?) -> SecIdentity? {
    
        var query :[String : Any]
        let searchResult : CFArray? = nil
        var foundIdentity: SecIdentity
        
        query =   [SecurityAttribute.SEC_CLASS : SecurityAttribute.SEC_CLASS_IDENTITY,
                   SecurityAttribute.SEC_RETURN_REF : true,
                   SecurityAttribute.SEC_RETURN_ATTRIBUTES : true,
                   SecurityAttribute.SEC_MATCH_LIMIT : SecurityAttribute.SEC_MATCH_LIMIT_ALL]
        
        if label.isEmpty == false {
            query[SecurityAttribute.SEC_ATTR_LABEL] = AW_CERT_PROVIDER_LABEL
        }
        
        let status : OSStatus = SecItemCopyMatching(query as CFDictionary, searchResult as CFTypeRef as? UnsafeMutablePointer<CFTypeRef?>)
        
        switch status {
        case errSecItemNotFound:
            return nil
        case errSecSuccess:
            guard (searchResult != nil) else {
                return nil
            }
            let resultCount : CFIndex = CFArrayGetCount(searchResult)
            for i in 0...resultCount - 1 {
                let thisResult : [String: Any] = unsafeBitCast(CFArrayGetValueAtIndex(searchResult, i), to: [String: Any].self)
                if let keyClass = thisResult[SecurityAttribute.SEC_ATTR_KEY_CLASS] , (keyClass as AnyObject).description == SecurityAttribute.SEC_ATTR_KEY_CLASS_PRIVATE {
                    foundIdentity = thisResult[SecurityAttribute.SEC_VALUE_REF] as! SecIdentity
                    return foundIdentity
                }
            }
            return nil
        default:
            let message = "\(LOG_TAG): Received error code \(status) while trying to search for identities matching label \(label)"
            print(message)
            error = NSError.init(domain: ErrorDetails.Certificate_Provider_Error_Domain,
                                 code: ErrorDetails.ERR_Save_Certificate_To_KeyChain_Failed,
                                    userInfo: [NSLocalizedDescriptionKey : message])
            return nil
        }
    }
    
    class func deleteStoredCertificate(errorRef eRef: inout Error?) {
        
        eRef = nil
        var status: OSStatus = noErr
        var queryIdentity: [AnyHashable : Any]?

             queryIdentity = [
                SecurityAttribute.SEC_ATTR_LABEL: AW_CERT_PROVIDER_LABEL,
                SecurityAttribute.SEC_CLASS: kSecClassIdentity
            ]
        

        // Delete the private key.
        if let identity = queryIdentity as [AnyHashable : Any]? {
            status = SecItemDelete(identity as CFDictionary)
        }
        if status != noErr && status != errSecItemNotFound {
            eRef = NSError(domain: ErrorDetails.Certificate_Provider_Error_Domain, code: ErrorDetails.ERR_Delete_Saved_Certificate_Failed, userInfo: [
                NSLocalizedDescriptionKey: "Failed to delete the saved certificate"
            ])
        }
        
    }
    
    class func addCertificateToKeychain(tempRef tRef:SecIdentity?, permRef pRef: inout SecIdentity?, errorRef eRef: inout Error?) {
        var status : OSStatus = 0
        pRef = nil
        eRef = nil
        let queryCertificate : [String : Any] = [SecurityAttribute.SEC_ATTR_LABEL:AW_CERT_PROVIDER_LABEL, SecurityAttribute.SEC_VALUE_REF: tRef!]
        
        status = SecItemAdd(queryCertificate as CFDictionary, pRef as CFTypeRef as? UnsafeMutablePointer<CFTypeRef?>)
        switch status {
        case errSecSuccess:
            print("Item successfully added to keychain")
        case errSecDuplicateItem:
            print("Item already present in keychain")
        default:
            let message = "\(LOG_TAG): Failed to save certificate to keychain, status = \(status)"
            print(message)
            eRef = NSError.init(domain: ErrorDetails.Certificate_Provider_Error_Domain,
                                code: ErrorDetails.ERR_Save_Certificate_To_KeyChain_Failed,
                                    userInfo: [NSLocalizedDescriptionKey : message])
        }
    }
}


