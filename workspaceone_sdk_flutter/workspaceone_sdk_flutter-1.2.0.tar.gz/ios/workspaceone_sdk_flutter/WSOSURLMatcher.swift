//
//  WSOSURLMatcher.swift
//  WorkspaceOneSdk
//
//  Created by VMWare, Inc.
//  Copyright © 2020 VMware, Inc. All rights reserved.
//  This product is protected by copyright and intellectual property laws in the United States and other countries as well as by international treaties.
//  WorkspaceOne products may be covered by one or more patents listed at http:www.vmware.com/go/patents.
//

import Foundation

private let EMPTY_STRING = ""

private let kRegexStart = "^"
private let kRegexEnd = "$"
private let kWildcard = "*"

private let kSchemeRegex = "((https?|ftps?)://)?"
private let kWwwRegex = "(www.)?"
private let kDomainRegex = "([\\.\\-a-zA-Z0-9])*"
private let kPathRegex = "([\\/\\.\\-a-zA-Z0-9])*"
private let kPortRegex = "(:[0-9]+)?"

private let kIPValueRegex = "[0-9]{1,3}"
private let kIPAddressRegex = "^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$"

private var trailingSlashSet: CharacterSet? = nil


class WSOSURLMatcher {
    
    class func load() {
        trailingSlashSet = CharacterSet.init(charactersIn: "/")
    }
    
    class func URLRegex(urlRegex : String, matchesRequest request: URLRequest )-> Bool {
        var userEnteredURLString = request.url?.absoluteString
        
        guard userEnteredURLString != nil, request.url?.host != nil  else {
            return false
        }
        var components : URLComponents =  URLComponents.init(string: userEnteredURLString!)!
        components.query = nil
        components.fragment = nil
        components.scheme = components.scheme?.lowercased()
        components.host = components.host?.lowercased()
        userEnteredURLString = components.string
        userEnteredURLString = userEnteredURLString?.trimmingTrailingCharacters(in: trailingSlashSet)
        
        return true
        
    }
    
    class func regex(withScheme scheme: String?, domain: String?, path: String?, request requestString: String?) -> String? {
        var regex: String?
        // Create Regex for Console URL
        var domainRegex = domain
        var schemeRegex: String?
        
        schemeRegex = scheme ?? "(https?|ftps?)?"
        
        
        // We prefix "www." only if its just domain and not for path
        if let domain = domain, domain.hasPrefix("www."), path == nil {
            domainRegex = kWwwRegex + (domain)
        }
        
        //Check if console and user entered url has the same domain.
        let domainsMatch = WSOSURLMatcher.consoleURLDomain(domainRegex, matchesUserEnteredURLDomain: requestString)
        if !domainsMatch {
            return nil
        }
        
        if let schReg = schemeRegex {
            regex = schReg.lowercased() + "://"
        }
        if let reg = regex, let doReg = domainRegex {
            regex = reg + doReg.lowercased()
        }
        
        if var path = path, !path.hasPrefix("/"), !path.contains("*") {
            // prefix with '/' if it is not already
            path = "/" + path
            if let reg = regex {
                regex = reg + "\(path)"
            }
            
        }
        return regex
    }
    
    class func validRegEx(forConsoleURL regex: String?, userEntered requestString: String?, shouldAppendEOL:inout  Bool) -> String? {

        var regexWithPath = regex
        var scheme: NSString?
        var domain: NSString?
        var path: NSString? = nil

        let scanner = Scanner(string: regex ?? "")
        // Get Scheme
        if regex?.contains("://") ?? false {
            scanner.scanUpTo("://", into: &scheme)
            scanner.scanString("://", into: nil)
        }

        // Get Domain
        scanner.scanUpTo("/", into: &domain)
        scanner.scanString("/", into: nil)
        
        if !scanner.isAtEnd {
            // Get Path
            path = (scanner.string as NSString).substring(from: scanner.scanLocation) as NSString
    
            // Remove query parameters from path
            if path!.contains("?") {
                scanner.scanUpTo("?", into: &path)
                scanner.scanString("?", into: nil)
            }

            // Remove fragments from path
            if path!.contains("#") {
                scanner.scanUpTo("#", into: &path)
                scanner.scanString("#", into: nil)
            }

            // Remove "/" if its the last character
            path = path!.trimmingCharacters(in: trailingSlashSet!) as NSString

            // If path is other than wildcard character, prefix it with '/'
            if (path != nil) && (path! as String != kWildcard) {
                path = "/\(path!)" as NSString
               
            }
            path = path!.replacingOccurrences(of: kWildcard, with: kPathRegex) as NSString
        } else {
            if !regexWithPath!.hasSuffix("/") {
                // Domain without a "/", so regex should match if anything comes appended to domain
                shouldAppendEOL = false
            } else {
                // URL is domain suffixed with / . It will be considered a path.
                // dont prefix www.
                path = EMPTY_STRING as NSString
            }
        }
        
        WSOSURLMatcher.domain(&domain, scheme: &scheme)

        // Replace wild card by alphabets or number or . or ? or -
        domain = domain!.replacingOccurrences(of: kWildcard, with: kDomainRegex) as NSString

        // Get regEx with scheme, domain and path.
        regexWithPath = WSOSURLMatcher.regex(withScheme: scheme as String?, domain: domain as String?, path: path as String?, request: requestString)

        return regexWithPath
    }
    
    class func urlRegex(_ urlRegex: String?, matchesRequest requestString: String?) -> Bool {
        let error: Error? = nil
        var preprocessedURL = urlRegex
        var shouldAppendEOL = false

        // End Of Line will be appended to the Regex only if console URL ends with wildcard
        shouldAppendEOL = (urlRegex?.hasSuffix(kWildcard)) ?? false ? false : true

        preprocessedURL = WSOSURLMatcher.validRegEx(forConsoleURL: preprocessedURL, userEntered: requestString, shouldAppendEOL: &shouldAppendEOL)
        // Escape reserved characters in regex like '.'
        preprocessedURL = preprocessedURL?.replacingOccurrences(of: ".", with: "\\.")

        if preprocessedURL == nil {
            // Domains did not match
            return false
        }
        
        preprocessedURL = kRegexStart + preprocessedURL!

        if shouldAppendEOL {
            //Add End Of Line to regex
            preprocessedURL = preprocessedURL! + kRegexEnd
        }

        var regex: NSRegularExpression? = nil
        do {
            regex = try NSRegularExpression(
                pattern: preprocessedURL!,
                options: .anchorsMatchLines)
        } catch {
        }
        let matches = regex?.numberOfMatches(
            in: requestString!,
            options: .reportProgress,
            range: NSRange(location: 0, length: requestString!.count)) ?? 0
        return matches > 0
    }
    
    class func consoleURLDomain(_ domainRegex: String?, matchesUserEnteredURLDomain requestString: String?) -> Bool {
        var domainRegex = domainRegex

        if domainRegex == nil {
            print("Domain is Nil in Console payload URL.")
            return false
        }

        var matches = 0
        domainRegex = kRegexStart + (domainRegex ?? "")

        if !(domainRegex?.hasSuffix(kWildcard) ?? false) {
            domainRegex = (domainRegex ?? "") + kRegexEnd
        }

        var regex: NSRegularExpression? = nil
        do {
            regex = try NSRegularExpression(
                pattern: domainRegex ?? "",
                options: .caseInsensitive)
        } catch {
            print("Error occured while evaluating regular expression")
        }
        if (requestString != nil) {
            let components = NSURLComponents(string: requestString!)
            var userEnteredURLDomain = components?.host
            if components?.port != nil {
                userEnteredURLDomain = "\(components?.host ?? ""):\(components?.port ?? 0)"
            }

            if let userEnteredURLDomain = userEnteredURLDomain {
                matches = (regex?.numberOfMatches(
                            in: userEnteredURLDomain,
                            options: .reportProgress,
                            range: NSRange(location: 0, length: userEnteredURLDomain.count)))!
            }
        }
        return matches > 0
    }
    class func domain(_ domain:inout  NSString?, scheme: inout  NSString?) {
       
        

        // Replace wildcard for port by (:[0-9]+)?
        if  ((domain?.contains(":*")) != nil) {
            domain = (domain?.replacingOccurrences(of: ":*", with: kPortRegex))! as NSString
        }

        // Provide http(s) depending on standard port
        if (domain?.hasSuffix(":80"))! || ((domain?.hasSuffix(":443")) != nil){

            let location = (domain as NSString?)?.range(of: ":").location ?? 0
            domain = (domain as NSString?)!.substring(to: location) as NSString
            scheme = "(https?)?"
        }
    }
    class func request(_ request: URLRequest?, inIAAllowedSites allowedSites: [Any]?) -> Bool {
        guard let allowedSites = allowedSites else {
            return false
        }
        
        for domain in allowedSites {
            guard let domain = domain as? String else {
                continue
            }
            if domain.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).count != 0 {
                if request != nil {
                    if WSOSURLMatcher.URLRegex(urlRegex: domain, matchesRequest: request!) {
                        return true
                    }
                }
            }
        }
        return false
    }
    
    
}
