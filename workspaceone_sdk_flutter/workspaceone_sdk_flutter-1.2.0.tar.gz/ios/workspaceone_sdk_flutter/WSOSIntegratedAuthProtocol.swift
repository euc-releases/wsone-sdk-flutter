//
//  WSOSIntegratedAuthProtocol.swift
//  WorkspaceOneSdk
//
//  Created by VMWare, Inc.
//  Copyright © 2020 VMware, Inc. All rights reserved.
//  This product is protected by copyright and intellectual property laws in the United States and other countries as well as by international treaties.
//  WorkspaceOne products may be covered by one or more patents listed at http:www.vmware.com/go/patents.
//

import Foundation
import AWSDK


private let WSOIntegratedAuthRequest = "AWIntegratedAuthRequest"

let kAWPluginVersion = "2.0"

class WSOSIntegratedAuthProtocol : URLProtocol, URLSessionDelegate, URLSessionDataDelegate, URLSessionTaskDelegate {
    
    private var completionBlock: ((_ disposition: URLSession.AuthChallengeDisposition, _ credential: URLCredential?) -> Void)?
    private var allowedMethod = false

    private var session: URLSession?
    private var response: URLResponse?
    private var challenge: URLAuthenticationChallenge?
    private var sessionTask: URLSessionTask?
    private var responseData: Data?
    private var sentCredentials = false
    
    
    deinit {
        completionBlock = nil
        if (session != nil) {
            session?.invalidateAndCancel()
            session = nil
        }
        response = nil
        challenge = nil

        sessionTask = nil
    }
    
    override class func canInit(with request: URLRequest) -> Bool {
        var canInit = true
        
        if let pluginVersion = URLProtocol.property(forKey: WSOIntegratedAuthRequest, in: request) {
            if pluginVersion as! String == kAWPluginVersion {
                canInit = false
            }
        } else if WSOSIntegratedAuthProtocol.isDSRequest(request) {
            canInit = false
        } else if (request.url?.scheme != "http") && (request.url?.scheme != "https") {
            canInit = false
        } else if !WSOSIntegratedAuthProtocol.useIntigratedAuth() {
            canInit = false
        } else if !WSOSIntegratedAuthProtocol.requestIsAllowed(request) {
            canInit = false
        }
        print("Can AWPlugin handle this Integrated Auth request - \(canInit ? "YES" : "NO")")
        return canInit
    }
    
    override class func canonicalRequest(for request: URLRequest) -> URLRequest {
        return request
    }
    
    override init(request: URLRequest,
                  cachedResponse: CachedURLResponse?,
                  client: URLProtocolClient?) {
        let mutReq = request as? NSMutableURLRequest
        if let mutReq = mutReq {
            WSOSIntegratedAuthProtocol.setProperty(kAWPluginVersion, forKey: WSOIntegratedAuthRequest, in: mutReq)
        }

        super.init(request: mutReq! as URLRequest, cachedResponse: cachedResponse, client: client)
        
    }
    
    override func startLoading() {
        let defaultConfigObject = URLSessionConfiguration.default

        let newSess = URLSession(configuration: defaultConfigObject, delegate: self, delegateQueue: nil)

        self.session = newSess

        if request.httpBody != nil || request.httpBodyStream != nil {
            let uploadTask = newSess.uploadTask(with: request, from: WSOSIntegratedAuthProtocol.httpBody(request)!)
            uploadTask.resume()
            self.sessionTask = uploadTask
        } else {
            let dataTask = newSess.dataTask(with: request)
            dataTask.resume()
            self.sessionTask = dataTask
        }
    }
    
    class func httpBody(_ req: URLRequest?) -> Data? {
        if let httpStreamBody = req?.httpBodyStream {
            var data = NSMutableData()
            var buffer = [UInt8](repeating: 0, count: 4096)
            httpStreamBody.open()
            while httpStreamBody.hasBytesAvailable {
                let length = httpStreamBody.read(&buffer, maxLength: 4096)
                if length == 0 {
                    httpStreamBody.close()
                   
                    break
                } else {
                    data.append(&buffer, length: length)
                }
            }
            return data as Data
            
        }
        return req?.httpBody
    }
    
    override func stopLoading() {
        OperationQueue.main.addOperation({ [self] in

            if self.challenge != nil {

                let challenge = self.challenge
                self.challenge = nil

                if client!.responds(to: #selector(URLProtocolClient.urlProtocol(_:didCancel:))) {
                    if let challenge = challenge {
                        client!.urlProtocol(self, didCancel: challenge)
                    }
                }
            }
        })

        if let task = sessionTask {
            task.cancel()
        }
    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        self.challenge = challenge
        self.sessionTask = task
        completionBlock = completionHandler
        handleChallenge()
    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        let newRequest = NSMutableURLRequest(
            url: request.url!,
            cachePolicy: request.cachePolicy,
            timeoutInterval: request.timeoutInterval)

        newRequest.httpMethod = request.httpMethod!
        if request.httpBody != nil {
            newRequest.httpBody = request.httpBody
        } else if request.httpBodyStream != nil {
            newRequest.httpBodyStream = request.httpBodyStream
        }

        if response != nil {
            WSOSIntegratedAuthProtocol.setProperty("", forKey: WSOIntegratedAuthRequest, in: newRequest)

            client!.urlProtocol(
                self,
                wasRedirectedTo: newRequest as URLRequest,
                redirectResponse: response)

            completionHandler(nil)
        } else {
            completionHandler(newRequest as URLRequest)
        }
    }
    
    func handleChallenge() {
        let authenticationMethod = challenge?.protectionSpace.authenticationMethod
        print("Authentication Method \(authenticationMethod ?? "")")
        var success = false
        var errorObj: Error?

        if (NSURLAuthenticationMethodClientCertificate == authenticationMethod)
        {
            
            do {
                try AWController.clientInstance().canHandle(protectionSpace: challenge?.protectionSpace)
                success = AWController.clientInstance().handleChallengeForURLSession(challenge: challenge, completionHandler: completionBlock)
            } catch  {
                errorObj = error
            }
        }

        if let error = errorObj {
            print("Success:\(success) - Error: \(error) for request: [\(request.url?.absoluteString ?? "")]")
        }
        if !success {
              handle(challenge, for: task?.originalRequest)
        }
    }
    
    func handle(_ challenge: URLAuthenticationChallenge?,
                for request: URLRequest?) {
        if NSURLAuthenticationMethodServerTrust == challenge?.protectionSpace.authenticationMethod {

            print("Handling ServerTrust challenge")
            let trustRef = challenge?.protectionSpace.serverTrust
            var trust_result: SecTrustResultType = .invalid

            if let trustRef = trustRef {
                SecTrustEvaluate(trustRef, &trust_result)
                print("kSecTrustResult \(trust_result)")
            }
            
            if .proceed == trust_result || .unspecified == trust_result || .recoverableTrustFailure == trust_result {
                let serverTrustCredential : URLCredential? = URLCredential(trust: trustRef!)
                    if let serverTrustCredential = serverTrustCredential {
                        print("calling challenge completion block for server trust")
                        completionBlock!(URLSession.AuthChallengeDisposition.useCredential, serverTrustCredential)
                        return
                    } else {
                        print("Unable to complete serverTrust")
                    }
                } else {
                    print("Do default handling")
                    completionBlock!(URLSession.AuthChallengeDisposition.performDefaultHandling, URLCredential(trust: trustRef!))
                    return
                }
        }
        else if NSURLAuthenticationMethodNegotiate == challenge?.protectionSpace.authenticationMethod {
            print("Handling Negotiate challenge")
            return completionBlock!(URLSession.AuthChallengeDisposition.useCredential, nil)
        }
        
        if WSOSIntegratedAuthProtocol.useIntigratedAuth() && WSOSIntegratedAuthProtocol.requestIsAllowed(request) && canHandle(challenge?.protectionSpace) {
        }
        
        switch challenge?.previousFailureCount {
            case 0:
                let sentChallengeResponse = useStoredCreds(for: challenge, withOutDomain: false)
                // In case we don't have un/pwd, get credentials from anchor app.
                if !sentChallengeResponse {
                    sendUpdatedCredentials(for: challenge)
                }
                break
        case 1:
            let sentChallengeResponse = useStoredCreds(for: challenge, withOutDomain: true)
            sentCredentials = false
            if !sentChallengeResponse {
                // if the username we tried did not have domain, then we need to get new creds from Anchor app.
                sendUpdatedCredentials(for: challenge)
            }
            break
        case 2 :
            var sentChallengeResponse = false
            if sentCredentials {
                sentChallengeResponse = useStoredCreds(for: challenge, withOutDomain: true)
                sentCredentials = false
            }
            if !sentChallengeResponse {
                //We tried to validate with domain\username and username, both fail, get new creds from Anchor app
                sendUpdatedCredentials(for: challenge)
            }
            break
        case 3:
            let sentChallengeResponse = useStoredCreds(for: challenge, withOutDomain: true)

            if !sentChallengeResponse {
                print("All cases tried")
                client?.urlProtocol(self, didReceive: challenge!)
            }
            break
        default:
            print("default case failure count - \(challenge?.previousFailureCount ?? 999)")
            client?.urlProtocol(self, didReceive: challenge!)
            break
        }
    }
    func sendUpdatedCredentials(for challenge: URLAuthenticationChallenge?) {
        AWController.clientInstance().updateUserCredentials(completion: { [self] success, error in
            if success {
                sentCredentials = true
                print("success in receiving new credentials")
                let sentChallengeResponse = useStoredCreds(for: challenge, withOutDomain: false)
                if !sentChallengeResponse {
                    print(" No Credentials to send - default")
                    if let challenge = challenge {
                        client?.urlProtocol(self, didReceive: challenge)
                    }
                }
            } else {
                if let error = error {
                    print("defaultError updating credentials - \(error)")
                }
                if let challenge = challenge {
                    client?.urlProtocol(self, didReceive: challenge)
                }
            }
        })
    }
    
    func urlSession(_ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive data: Data) {

        if (responseData != nil) {
            responseData?.append(data)
        } else {
            responseData = data
        }
        client?.urlProtocol(self, didLoad: data)
    }
    
    func urlSession(_ session: URLSession,
                    dataTask: URLSessionDataTask,
                    didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {

        let httpResponse = response as? HTTPURLResponse
        if httpResponse?.statusCode == 304 {
            /*
                     Putting null check since we may not be the ones that put the cache headers on the
                     request, and therefore wouldn't have have a valid response.
                     */
            if let cachedResponse = cachedResponse {
                client?.urlProtocol(self, cachedResponseIsValid: cachedResponse)
            }
        }

        client?.urlProtocol(
            self,
            didReceive: response,
            cacheStoragePolicy: .allowed)

        self.response = response

        completionHandler(.allow)
    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        let response = task.response as? HTTPURLResponse
        if let response = response {
            print("URL response: \(response)")
        }

        if error == nil {
            client?.urlProtocolDidFinishLoading(self)
        } else {
            if let error = error {
                client?.urlProtocol(self, didFailWithError: error)
            }
            responseData = nil
            self.response = nil
        }
    }
    func useStoredCreds(for challenge: URLAuthenticationChallenge?,
                        withOutDomain: Bool) -> Bool {
        let enrollmentAccount = AWController.clientInstance().account

        if enrollmentAccount != nil && enrollmentAccount?.username.count != nil && enrollmentAccount?.password.count != nil {
            var username = enrollmentAccount?.username

            if withOutDomain {
                let userNameParts = enrollmentAccount?.username.components(separatedBy: "\\")
                if userNameParts?.count == 2 {
                    username = userNameParts?[1]
                } else {
                    return false
                }
            }
            let isPasswordNilOrEmpty = !(enrollmentAccount?.password != nil && enrollmentAccount?.password.count != nil)
            print(String(format: "username - %lu, password - %@ ", UInt(username?.count ?? 0), isPasswordNilOrEmpty ? "empty" : "present"))
            
            let credentials = URLCredential(user: username!, password: enrollmentAccount!.password, persistence: .forSession)

            completionBlock!(URLSession.AuthChallengeDisposition.useCredential, credentials)
            return true
        }
        
        let isPasswordNilOrEmpty = !(challenge?.proposedCredential?.password != nil && (challenge?.proposedCredential?.password?.count ?? 0) != 0)
        print(String(format: "proposedCredential username - %lu, password - %@ ", UInt(challenge?.proposedCredential?.user?.count ?? 0), isPasswordNilOrEmpty ? "empty" : "present"))
        if challenge?.proposedCredential != nil {
            completionBlock!(URLSession.AuthChallengeDisposition.useCredential, challenge?.proposedCredential)
            return true
        }
        return false
    }
    
    func canHandle(_ protectionSpace: URLProtectionSpace?) -> Bool {

        let authenticationMethod = protectionSpace?.authenticationMethod

        var handleProtectionSpace = false

        handleProtectionSpace = authenticationMethod == NSURLAuthenticationMethodNTLM || authenticationMethod == NSURLAuthenticationMethodHTTPBasic || authenticationMethod == NSURLAuthenticationMethodDefault


        return handleProtectionSpace
    }
    
    class func useIntigratedAuth() -> Bool {
        return WSOSBridge.sharedInstance().enableIntegratedAuthentication()
    }
    
    class func isDSRequest(_ request: URLRequest?) -> Bool {
        if let dsURLString = WSOSBridge.sharedInstance().serverName() {
            let dsURL = URL(string: dsURLString)
            var isDSRequest = false
            if (dsURL?.host?.count ?? 0) > 0 {
                let dsURLRegex = "*\(dsURL?.host ?? "")*"
                isDSRequest = WSOSURLMatcher.URLRegex(urlRegex: dsURLRegex, matchesRequest: request!)
                
            }
            return isDSRequest
        }
       return false
    }
    
    class func requestIsAllowed(_ request: URLRequest?) -> Bool {
        let allowedDomains : [Any]? = WSOSBridge.sharedInstance().allowedSitesForIA()
        var retVal = false
        retVal = WSOSURLMatcher.request(request, inIAAllowedSites: allowedDomains)
        return retVal
    }
}
