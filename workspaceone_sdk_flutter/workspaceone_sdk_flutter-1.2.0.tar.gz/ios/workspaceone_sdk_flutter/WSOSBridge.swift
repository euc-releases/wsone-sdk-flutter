//
//  WSOSBridge.swift
//  WorkspaceOneSdk
//
//  Created by VMWare, Inc.
//  Copyright © 2020 VMware, Inc. All rights reserved.
//  This product is protected by copyright and intellectual property laws in the United States and other countries as well as by international treaties.
//  WorkspaceOne products may be covered by one or more patents listed at http:www.vmware.com/go/patents.
//

import Foundation
import AWSDK
/*
 * Document Open Interface Status
 */
enum WSOOpenFileStatus : Int {
    case success
    case errorPathNotSpecified
    case errorInvalidPath
}

/*
 * WSOSDKBridgeDelegate Protocol
 */
protocol WSOSDKBridgeDelegate: AnyObject {
    func initSuccess()
    func initFailure()
    func wipe()
    func lock()
    func unlock()
    func stopNetworkActivity(_ networkActivityStatus: NetworkActivityStatus)
    func resumeNetworkActivity()
}

/*
 * AWSDKCertificateReceiver Protocol
 */
protocol AWSDKCertificateReceiver: AnyObject {
    func receivedCertificate(_ cert: SecIdentity?,withError error: Error?)
}

internal struct InfoBundleConstants {
    static let kUrlTypes = "CFBundleURLTypes"
    static let kUrlName = "CFBundleURLName"
    static let kUrlSchemes = "CFBundleURLSchemes"
    static let kSdkUrlIdentifier = "com.airwatch.sdk"
}

class WSOSBridge : NSObject, WSOSDKBridgeDelegate, AWControllerDelegate {
    
    internal let defaultScheme = "wsoexample"
    var controller: AWController = AWController.clientInstance()
    weak var certReceiver: AWSDKCertificateReceiver?
    var documentHandler: WSOSDocumentOpenHandler?
    weak var bridgeDelegate: WSOSDKBridgeDelegate?
    var initialized = false
    private static var sharedBridge: WSOSBridge = WSOSBridge()
    var _isCompromised = false
    var _deviceInfo : DeviceInformation? = nil
    var _isEnrolled = false
    /*
     * sharedInstance of WorkspaceOneSDK Bridge.
     */
    class func sharedInstance() -> WSOSBridge {
        return sharedBridge
    }
    
    /*
     * Constructor.
     */
    override init() {
        super.init()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleUpdatedProfile(_:)),
            name: NSNotification.Name("WSONotificationCommandManagerInstalledNewProfile"),
            object: nil)
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleOpenURL(_:)),
            name: Notification.Name("UIApplicationOpenURLOptionsSourceApplicationKey"),
            object: nil)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleOpenURL(_:)),
            name: Notification.Name("UIApplicationLaunchOptionsSourceApplicationKey"),
            object: nil)
    }
    
    /*
     * startWorkspaceOneSDK is used to start the AWController.
     */
    func startWorkspaceOneSDK() {
        controller.callbackScheme = findCallbackScheme()
        print("Callbackscheme: \(controller.callbackScheme)")
        controller.delegate = self
        controller.start()
    }
    
    /*
     * isInitialized returns true if WorkspaceOneSDK is initialized .
     */
    func isInitialized() -> Bool {
        return initialized
    }
    
    /*
     * fetchCertificates if SDK is initialized else starts SDK.
     */
    func fetchCertificates(for certReceiver: AWSDKCertificateReceiver?) {
        self.certReceiver = certReceiver
        if isInitialized() {
            print("In AWSDKBridge -fetchCertForReceiver, SDK already initialized")
            controller.loadCommands()
        } else {
            print("In AWSDKBridge -fetchCertForReceiver, SDK not yet initialized")
            startWorkspaceOneSDK()
        }
    }
    
    /*
     * AWControllerDelegate : fetchCertificates if SDK is initialized else starts SDK.
     */
    func controllerDidFinishInitialCheck(error: NSError?) {
        if let error = error {
            print("In AWSDKBridge -initialCheckDoneWithError: Initial check failed with error:\(error.localizedDescription)")
            self.initFailure()
        }
        else{
            print("In AWSDKBridge -initialCheckDoneWithError: Initial check succeeded")
            initialized = true
            print("Registering for Integrated Authentication using SDK")
            URLProtocol.registerClass(WSOSIntegratedAuthProtocol.self)
            var identityRef : SecIdentity? = nil
            var errorObj : Error? = nil
            AWController.clientInstance().exportIdentityCertificates { [self] dict, error in
                if let error = error {
                    print("In AWSDKBridge -exportIdentityCertificatesWithCompletion: with error: \(error.localizedDescription)")
                }
                if let dict = dict {
                    print("In AWSDKBridge -exportIdentityCertificatesWithCompletion: with dict: \(dict)")
                }
                let uncategorizedCertsArray: [PKCS12Certificate?]? = dict?["com.vmware.identity.uncategorized"]
                if let uncategorizedCerts = uncategorizedCertsArray ,uncategorizedCerts.count > 0 , let cert = uncategorizedCerts[0] {
                    if cert.data.count > 0 && cert.importExportPassphrase.count > 0 {
                        WSOSCertificateUtility.importCertToKeychain(certData: cert.data, password: cert.importExportPassphrase, identityRef: &identityRef, errorRef: &errorObj)
                        if let err = errorObj {
                            print("In AWSDKBridge AWCertificateUtility-importCertToKeychain: with error:\(err.localizedDescription)")
                        }
                    }
                    if (self.certReceiver != nil) {
                        self.certReceiver?.receivedCertificate(identityRef, withError: errorObj)
                    }
                }
            }
            self.initSuccess()
            self.getDeviceInformation()
        }
    }
    
    /* receivedProfiles is called after initialCheckDoneWithError.
     * This will retrieve all of the SDK profiles queued by the server.
     * The most recent profile will be the lastObject in the profiles array.
     */
    func receivedProfiles(_ profiles: [AnyHashable]?) {
        if let profiles = profiles {
            print("In AWSDKBridge -receivedProfiles: got \(Int(profiles.count )) profiles")
        }
    }
    
    /*
     * Handle Open URL notofication.
     */
    @objc func handleOpenURL(_ notification: Notification?) {
            if let notification = notification {
            if let object = notification.object {
                print("In handleOpenURL \(object):")
            }
            let url = notification.object as! URL
            let sourceApplication = notification.userInfo?[UIApplication.OpenURLOptionsKey.sourceApplication] as? String
            _ =  self.controller.handleOpenURL(url, fromApplication: sourceApplication)
        }
    }
    
    /*
     * Handle Updated Profile Notificaton.
     */
    @objc func handleUpdatedProfile(_ notification: Notification?) {

        // Get the profile that just got received in this call; it could be an application profile or an SDK profile.
        let profile = notification?.object as? Profile
        
        if profile?.profileType ==  AWSDK.ConfigurationProfileType.sdk{
            print("In AWSDKBridge -handleUpdatedProfile, got SDK profile")
        }
    }
    
    /*
     * Retrieves device information and Compromised status
     */
    func getDeviceInformation() {
        DeviceInformationController.sharedController.refreshDeviceCompromisedStatus { [self](status, value1, value2) in
            self._isCompromised = status
        }
        self.controller.queryDeviceEnrollmentStatus { status, error in
                    self._isEnrolled = status
        }
        DeviceInformationController.sharedController.fetchDeviceInformation { [self](deviceInformation, error) in
            if let error = error {
                print ("Error retrieving device information" + error.localizedDescription)
            }
            self._deviceInfo = deviceInformation
        }
    }
    
    /*
     * Group ID .
     */
    func groupId () -> String? {
        if let account = self.controller.account {
            return account.activationCode
        }
        return nil
    }
    
    /*
     * Logged In Current User.
     */
    func username () -> String? {
        if let account = self.controller.account {
            return account.username
        }
        return nil
    }
    
    /*
     * Server URL of Current User.
     */
    func serverName () -> String? {
        return self.controller.deviceServicesURL()
    }
    
    /*
     * Restriction Flag to Enable Copy Paste.
     */
    func allowCopyPaste() -> Bool {
        if let sdkProfile = self.controller.sdkProfile(), let payload = sdkProfile.restrictionsPayload {
            return payload.preventCopyPaste
        }
        return false
    }
    
    /*
     * Restriction Flag for Allowing Offline Access.
     */
    func allowOffline() -> Bool {
        if let sdkProfile = self.controller.sdkProfile(), let payload = sdkProfile.offlineAccessPayload {
            return payload.enableOfflineAccess
        }
        return false
    }
    
    /*
     * Restriction Flag to Restrict Document to Apps.
     */
    func restrictDocumentToApps() -> Bool {
        if let sdkProfile = self.controller.sdkProfile(), let payload = sdkProfile.restrictionsPayload {
            return payload.restrictDocumentToApps
        }
        return false
    }
    
    /*
     * Restriction Flag to Enable Integrated Authentication.
     */
    func enableIntegratedAuthentication() -> Bool {
        if let sdkProfile = self.controller.sdkProfile(), let payload = sdkProfile.authenticationPayload {
            return payload.enableIntegratedAuthentication
        }
        return false
    }
    
    /*
     * Allowed Sites for access.
     */
    func allowedSitesForIA() -> [String] {
        if let sdkProfile = self.controller.sdkProfile(), let payload = sdkProfile.authenticationPayload {
            return payload.allowedSites
        }
        return []
    }
    
    /*
     * Allowed Application list.
     */
    func allowedApplications() -> [String] {
        if let sdkProfile = self.controller.sdkProfile(), let payload = sdkProfile.restrictionsPayload {
            return payload.allowedApplications
        }
        return []
    }
    
    /*
     * Custom Settings.
     */
    func customSettings() ->  String? {
        if let sdkProfile = self.controller.sdkProfile(), let payload = sdkProfile.customPayload {
            return payload.settings
        }
        return ""
    }
    
    /*
     * Flag for Device is Compliant.
     */
    func isCompliant() -> Bool  {
        guard let compliant = _deviceInfo?.complianceStatus else {
            return false
        }
        return compliant.rawValue == ComplianceStatus.compliant.rawValue
    }
    
    /*
     * Flag for Device is Compromised.
     */
    func isCompromised() -> Bool {
        return self._isCompromised
    }
    
    /*
     * Flag for Device is Enrolled.
     */
    func isEnrolled() -> Bool {
        return self._isEnrolled
    }
    /*
     * Initialize Success Call back.
     */
    func initSuccess() {
        if let delegate = self.bridgeDelegate {
           delegate.initSuccess()
        }
    }
    
    /*
     * Initialize Failure call back.
     */
    func initFailure() {
        if let delegate = self.bridgeDelegate {
            delegate.initFailure()
        }
    }
    
    /*
     * Wipe Data call back.
     */
    func wipe() {
        if let delegate = self.bridgeDelegate {
            delegate.wipe()
        }
    }
    
    /*
     * Lock Device call back.
     */
    func lock() {
        if let delegate = self.bridgeDelegate {
            delegate.lock()
        }
    }
    
    /*
     * Unlock Device call back.
     */
    func unlock() {
        if let delegate = self.bridgeDelegate {
            delegate.unlock()
        }
    }
    
    /*
     * Stop Network Activity call back.
     */
    func stopNetworkActivity(_ networkActivityStatus: NetworkActivityStatus) {
        if let delegate = self.bridgeDelegate {
            delegate.stopNetworkActivity(networkActivityStatus)
        }
    }
    
    /*
     * Resume Network Activity call back.
     */
    func resumeNetworkActivity() {
        if let delegate = self.bridgeDelegate {
            delegate.resumeNetworkActivity()
        }
    }

    /*
     * Register Token for APNS.
     */
    func registerPushNotificationToken(token: String) {
        self.controller.APNSToken = token
    }
    
    /*
     * Find Call Back Scheme.
     */
    internal func findCallbackScheme() -> String {
        let urls: [[String:Any]]? = self.getURLTypesFromPlist()
        if let urls = urls {
            for dict in urls {
                if case let schemeName as String = dict[InfoBundleConstants.kUrlName], schemeName ==  InfoBundleConstants.kSdkUrlIdentifier {
                    let schemes = dict[InfoBundleConstants.kUrlSchemes] as? [String]
                    if let schemes = schemes, let callbackScheme = schemes.first {
                        return callbackScheme
                    }
                }
            }
        }
        return self.defaultScheme
    }
    
    internal func getURLTypesFromPlist() -> [[String:Any]]? {
        return Bundle.main.object(forInfoDictionaryKey: InfoBundleConstants.kUrlTypes) as? [[String : String]]
    }
    
    /*
     * Open File within ViewController.
     */
    func openFile(path : String?, from viewController:UIViewController?) -> WSOOpenFileStatus {
        guard let path = path else {
            return .errorPathNotSpecified
        }
        let fileUrl = URL.init(fileURLWithPath: path)
        
        guard fileUrl.isFileURL else {
            return .errorInvalidPath
        }
        
        if (self.documentHandler == nil) {
            self.documentHandler = WSOSDocumentOpenHandler.init(sourceViewController: viewController)
        }
        self.documentHandler?.restrictDocumentToApps = self.restrictDocumentToApps()
        self.documentHandler?.whitelistedApplications = self.allowedApplications()
        self.documentHandler?.open(fileUrl)
        return .success
    }
    
    /*
     * Open File.
     */
    func openFile(path : String?)->WSOOpenFileStatus {
        guard let path = path else {
            return .errorPathNotSpecified
        }
        let fileUrl = URL.init(fileURLWithPath: path)
        
        guard fileUrl.isFileURL else {
            return .errorInvalidPath
        }
        
        if (self.documentHandler == nil) {
            self.documentHandler = WSOSDocumentOpenHandler.init()
        }
        self.documentHandler?.restrictDocumentToApps = self.restrictDocumentToApps()
        self.documentHandler?.whitelistedApplications = self.allowedApplications()
        self.documentHandler?.open(fileUrl)
        return .success
    }
}

