package com.vmware.workspaceone_sdk_flutter

import android.app.Activity
import android.net.Uri
import android.text.TextUtils
import android.util.Log
import com.airwatch.dlp.openIn.UriOpenerFactory
import com.airwatch.notification.PushNotificationManager
import com.airwatch.sdk.AirWatchSDKException
import com.airwatch.sdk.SDKManager
import com.airwatch.sdk.configuration.SDKConfigurationKeys
import com.airwatch.sdk.context.SDKContextManager
import com.airwatch.util.Logger
import com.airwatch.util.Logger.e
import java.util.*

class WorkspaceOneSdkBridge {
    var sDKManagerInstance: SDKManager? = null
        private set
    private var reactActivity: Activity? = null
    fun initWorkspaceOneSDKManager(activity: Activity, initListener: InitializationListener) {
        Thread(object : Runnable {
            override fun run() {
                try {
                    Log.v("SDK Init", "in Kotlin file")
                    Log.d("SDK Init", "SDK Initialize")
                    reactActivity = activity
                    sDKManagerInstance = SDKManager.init(activity.applicationContext)
                    if (sDKManagerInstance != null) {
                        Log.d("SDK Init", "SDK initSuccess")
                        initListener.initSuccess()
                    } else {
                        initListener.initFailure()
                    }
                } catch (awse: AirWatchSDKException) {
                    e(LOG_TAG, "Exception initializing AirWatch SDK", awse)
                    initListener.initFailure()
                }
            }
        }).start()
    }

    @get:Throws(AirWatchSDKException::class)
    val isInitialized: Boolean
        get() = sDKManagerInstance != null

    // Connection information
    @get:Throws(AirWatchSDKException::class)
    val userName: String
        get() = sDKManagerInstance!!.enrollmentUsername

    @get:Throws(AirWatchSDKException::class)
    val groupId: String
        get() = sDKManagerInstance!!.groupId

    @get:Throws(AirWatchSDKException::class)
    val serverName: String
        get() = sDKManagerInstance!!.serverName

    // Restrictions methods
    @Throws(AirWatchSDKException::class)
    fun allowCopyPaste(): Boolean {
        val config = SDKContextManager.getSDKContext().sdkConfiguration
        val allowCopyPaste = config.getValuesWithKeyStartWith(SDKConfigurationKeys.TYPE_DATA_LOSS_PREVENTION, SDKConfigurationKeys.ENABLE_COPY_PASTE)
        return if (TextUtils.isEmpty(allowCopyPaste)) {
            true
        } else java.lang.Boolean.valueOf(allowCopyPaste)
    }

    @get:Throws(AirWatchSDKException::class)
    val isOfflineAllowed: Boolean
        get() {
            val config = SDKContextManager.getSDKContext().sdkConfiguration
            val allowOffline = config.getValuesWithKeyStartWith(SDKConfigurationKeys.TYPE_OFFLINE_ACCESS, SDKConfigurationKeys.ENABLE_OFFLINE_ACCESS)
            return if (TextUtils.isEmpty(allowOffline)) {
                true
            } else java.lang.Boolean.valueOf(allowOffline)
        }

    @get:Throws(AirWatchSDKException::class)
    val restrictDocumentToApps: Boolean
        get() {
            val config = SDKContextManager.getSDKContext().sdkConfiguration
            val restrictDocumentToApps = config.getValuesWithKeyStartWith(SDKConfigurationKeys.TYPE_DATA_LOSS_PREVENTION, SDKConfigurationKeys.LIMIT_OPEN_WITH)
            return if (TextUtils.isEmpty(restrictDocumentToApps)) {
                true
            } else java.lang.Boolean.valueOf(restrictDocumentToApps)
        }

    @Throws(AirWatchSDKException::class)
    fun allowedApplications(): List<String>? {
        val config = SDKContextManager.getSDKContext().sdkConfiguration
        if (!restrictDocumentToApps) {
            return null;
        }
        val allowedApps = config.getValuesWithKeyStartWith(SDKConfigurationKeys.TYPE_DATA_LOSS_PREVENTION, SDKConfigurationKeys.ALLOWED_APPLICATIONS)

        if (!TextUtils.isEmpty(allowedApps)) {
            return allowedApps.split(",")
        } else {
            return null

        }
    }

    // Custom settings
    @get:Throws(AirWatchSDKException::class)
    val customSettings: String
        get() = sDKManagerInstance!!.customSettings

    // Uncategorized
    @get:Throws(AirWatchSDKException::class)
    val isCompliant: Boolean
        get() = sDKManagerInstance!!.isCompliant

    @get:Throws(AirWatchSDKException::class)
    val isCompromised: Boolean
        get() = sDKManagerInstance!!.isCompromised

    @get:Throws(AirWatchSDKException::class)
    val isEnrolled: Boolean
        get() = sDKManagerInstance!!.isEnrolled

    fun openFile(uri: Uri?) {
        UriOpenerFactory.getInstance().openUri(reactActivity, uri)
    }

    @Throws(AirWatchSDKException::class)
    fun registerPushNotificationToken(token: String?) {
        PushNotificationManager.getInstance(reactActivity!!.applicationContext).registerToken(token)
    }

    fun processMessage(title: String?, body: String?, payload: Map<String, Any>?) {
        PushNotificationManager.getInstance(reactActivity!!.applicationContext).processMessage(title!!, body!!, payload)
    }

    companion object {
        private val LOG_TAG = WorkspaceOneSdkBridge::class.java.simpleName
        val instance = WorkspaceOneSdkBridge()
    }
}