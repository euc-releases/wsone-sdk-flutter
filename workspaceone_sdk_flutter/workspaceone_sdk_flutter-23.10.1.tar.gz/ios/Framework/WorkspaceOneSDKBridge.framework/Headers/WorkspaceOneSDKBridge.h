//
//  WorkspaceOneSDKBridge.h
//  WorkspaceOneSDKBridge
//
//  Created by VMWare, Inc.
//  Copyright © 2020-2023 VMware, Inc. All rights reserved.
//  This product is protected by copyright and intellectual property laws in the United States and other countries as well as by international treaties.
//  WorkspaceOne products may be covered by one or more patents listed at http:www.vmware.com/go/patents.
//

#import <Foundation/Foundation.h>
#import "AWProfileWrapper.h"
//! Project version number for WorkspaceOneSDKBridge.
FOUNDATION_EXPORT double WorkspaceOneSDKBridgeVersionNumber;

//! Project version string for WorkspaceOneSDKBridge.
FOUNDATION_EXPORT const unsigned char WorkspaceOneSDKBridgeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WorkspaceOneSDKBridge/PublicHeader.h>

