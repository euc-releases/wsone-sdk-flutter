## 1.2.0

* Initial release:VMware Workspace ONE SDK for Flutter allows you to integrate the Workspace ONE SDKs for iOS and Android into your Flutter.

## 22.1.0

* VMware Workspace ONE SDK for Flutter is updated to SDK version 21.11.0

## 22.3.0

* VMware Workspace ONE SDK for Flutter is updated to SDK version 22.2.0

## 22.5.0

* VMware Workspace ONE SDK for Flutter is updated to SDK version 22.4.0

## 22.8.0

* VMware Workspace ONE SDK for Flutter is updated to iOS SDK 22.7.0 & Android SDK 22.8.0

## 22.12.0

* VMware Workspace ONE SDK for Flutter is updated to iOS SDK 22.10.0 & Android SDK 22.10.0

## 23.02.0

* VMware Workspace ONE SDK for Flutter is updated to iOS SDK 23.1.0 & Android SDK 23.01

## 23.05.0

* VMware Workspace ONE SDK for Flutter is updated to iOS SDK 23.4.0 & Android SDK 23.04

## 23.07.0

* VMware Workspace ONE SDK for Flutter is updated to iOS SDK 23.7.0 & Android SDK 23.07

## 23.07.1

* VMware Workspace ONE SDK for Flutter is updated to iOS SDK 23.7.0 & Android SDK 23.07

## 23.10.0

* VMware Workspace ONE SDK for Flutter is updated to iOS SDK 23.9.1 & Android SDK 23.09

## 23.10.1

* Minor changes : Watermark support for Flutter Android.

## 24.2.0

* VMware Workspace ONE SDK for Flutter is updated to iOS SDK 24.1.0 & Android SDK 24.01

## 24.2.1

* Minor changes : iOS sdk upgrade to 24.1.2
