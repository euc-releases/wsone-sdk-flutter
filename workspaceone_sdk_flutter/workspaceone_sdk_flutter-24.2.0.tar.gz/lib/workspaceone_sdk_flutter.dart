
import 'dart:async';

import 'package:flutter/services.dart';

class WorkspaceoneSdkFlutter {
  static const MethodChannel _channel =
      const MethodChannel('workspaceone_sdk_flutter');

  static Future<String?> get platformVersion async {
    final String? version = await _channel.invokeMethod('getPlatformVersion');
    return version;
  }

  // Start the WS1 SDK.
  static Future<void> get startSDK async {
     await _channel.invokeMethod('startSDK');
     return;
  }

  // Get the current username.  
  static Future<String?> get userName async {
    final String? userName = await _channel.invokeMethod('userName');
    return userName;
  }

  // Get the group id.
  static Future<String?> get groupId async {
    final String? groupId = await _channel.invokeMethod('groupId');
    return groupId;
  }

  // Get the server name.
  static Future<String?> get serverName async {
    final String? serverName = await _channel.invokeMethod('serverName');
    return serverName;
  }

  // Get the Data Loss Protection allowCopyPaste flag.
  static Future<bool?> get allowCopyPaste async {
    final bool? allowCopyPaste = await _channel.invokeMethod('allowCopyPaste');
    return allowCopyPaste;
  }

  // Get the Data Loss Protection allowOffline flag.
  static Future<bool?> get allowOffline async {
    final bool? allowOffline = await _channel.invokeMethod('allowOffline');
    return allowOffline;
  }

  // Get the customSettings.
  static Future<String?> get customSettings async {
    final String? customSettings = await _channel.invokeMethod('customSettings');
    return customSettings;
  }

  // Get the device isCompliant flag.
  static Future<bool?> get isCompliant async {
    final bool? isCompliant = await _channel.invokeMethod('isCompliant');
    return isCompliant;
  }

  // Get the device isCompromised flag.
  static Future<bool?> get isCompromised async {
    final bool? isCompromised = await _channel.invokeMethod('isCompromised');
    return isCompromised;
  }

  // Get the device isEnrolled flag.
 static Future<bool?> get isEnrolled async {
    final bool? isEnrolled = await _channel.invokeMethod('isEnrolled');
    return isEnrolled;
  }


  // Get the restrictDocumentToAppss flag.
  static Future<bool?> get restrictDocumentToApps async {
    final bool? restrictDocumentToApps = await _channel.invokeMethod('restrictDocumentToApps');
    return restrictDocumentToApps;
  }

  // Get the allowedApplication list to open the documents.
  static Future<List<String>?> get allowedApplications async {
    final List<String>? allowedApplications = await _channel.invokeMethod('allowedApplications');
    return allowedApplications;
  }

  // Open document at given path.
  static Future<bool?>  openFile(String path) async {
    final bool? version = await _channel.invokeMethod('openFile',<String, dynamic>{
        'path': path
      });
    return version;
  }

  // Register token with SDK for Pusk Notification..
  static Future<void>  registerPushNotificationToken(String token) async {
    return await _channel.invokeMethod('registerPushNotificationToken',<String, dynamic>{
        'token': token
      });
  }

  static Future<String?>  loadURL(String urlString) async {
    return await _channel.invokeMethod('loadURL',<String, dynamic>{
      'urlString': urlString
    });
  }

}
