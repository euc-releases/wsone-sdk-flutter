#import <Flutter/Flutter.h>

@interface WorkspaceoneSdkFlutterPlugin : NSObject<FlutterPlugin>
@end
