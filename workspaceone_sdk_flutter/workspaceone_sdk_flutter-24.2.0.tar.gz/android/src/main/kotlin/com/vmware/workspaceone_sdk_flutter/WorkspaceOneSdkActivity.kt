package com.vmware.workspaceone_sdk_flutter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.airwatch.geofencing.GeofencingUtility
import com.airwatch.login.IProxyStatusCallback
import com.airwatch.login.SDKBaseActivityDelegate
import com.airwatch.login.SDKGatewayActivityDelegate
import com.airwatch.sdk.configuration.SDKConfigurationKeys
import com.airwatch.sdk.context.SDKContextManager
import io.flutter.embedding.android.FlutterActivity


open class WorkspaceOneSdkActivity : FlutterActivity(), SDKBaseActivityDelegate.Callback, IProxyStatusCallback {

    protected lateinit var mSDKBaseActivityDelegate : SDKBaseActivityDelegate
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mSDKBaseActivityDelegate = SDKBaseActivityDelegate(this)
        mSDKBaseActivityDelegate.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        //shake device to feedBack listener
        mSDKBaseActivityDelegate.onResume()
        mSDKBaseActivityDelegate.addAndUpdateWatermark()
        if (mSDKBaseActivityDelegate.isAppReady) {
            val sdkConfiguration = SDKContextManager.getSDKContext().sdkConfiguration
            val isGeofencingEnable = sdkConfiguration.getBooleanValue(
                SDKConfigurationKeys.GEOFENCE_GROUP,
                SDKConfigurationKeys.ENABLE_GEOFENCING)
            if (isGeofencingEnable) {
                val gps = GeofencingUtility.getInstance()
                gps.checkGeofencingControl(this)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        mSDKBaseActivityDelegate.onPause()
    }

    override fun onStart() {
        super.onStart()
        mSDKBaseActivityDelegate.onStart()
    }

    override fun onStop() {
        super.onStop()
        mSDKBaseActivityDelegate.onStop()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        mSDKBaseActivityDelegate.onActivityResult(requestCode, resultCode,data)
    }

    /**
     * this api will work in case of sso disabled only
     */
    protected open fun logout() {
        mSDKBaseActivityDelegate.logout()
    }

    /**
     * this api will work in case of sso disabled and authentication type is passcode
     */
    protected open fun changePasscode() {
        mSDKBaseActivityDelegate.changePasscode()
    }


    override fun onDestroy() {
        super.onDestroy()
        mSDKBaseActivityDelegate.onDestroy()
    }

    open fun isTunnelingEnabled(): Boolean {
        return (mSDKBaseActivityDelegate as SDKGatewayActivityDelegate).isTunnelingEnabled
    }


    companion object {
        fun getContext(): Context? {
            return getContext()
        }
    }
    override fun proxyStatusUpdated(i: Int) {}
    override fun onTimeOut(sdkBaseActivityDelegate: SDKBaseActivityDelegate) {}
    override fun onPointerCaptureChanged(hasCapture: Boolean) {}
}